package com.azsnowsports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

/**
 * @author Zac Almas and Austin Driver
 *
 * Main application class
 */
@SpringBootApplication
@EnableEurekaClient
public class BlogApiApplication {

	/**
	 * Main application method
	 * @param args Arguments passed
	 */
	public static void main(String[] args) {
		SpringApplication.run(BlogApiApplication.class, args);
	}

}
