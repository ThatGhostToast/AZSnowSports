package com.azsnowsports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author Zac Almas and Austin Driver
 *
 * Main test class
 */
@SpringBootTest
class BlogApiApplicationTests {

	/**
	 * Method for testing
	 */
	@Test
	void contextLoads() {
	}

}
