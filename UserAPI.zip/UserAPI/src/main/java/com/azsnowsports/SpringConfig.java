package com.azsnowsports;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.azsnowsports.business.UserBusinessService;

/**
 * @author Zac Almas and Austin Driver
 * 
 * Configuration file for the application
 */
@Configuration
public class SpringConfig {	
	/**
	 * User business service bean
	 * @return Returns a new user business service
	 */
	@Bean(name="userBusinessService")
	public UserBusinessService getUserBusiness()
	{
		return new UserBusinessService();
	}
	
}
