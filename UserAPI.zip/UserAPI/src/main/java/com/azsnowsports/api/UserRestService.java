package com.azsnowsports.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.azsnowsports.business.UserBusinessService;
import com.azsnowsports.model.UserModel;

/**
 * @author Zac Almas and Austin Driver
 * 
 * Class used for the REST API
 */
@RestController
@RequestMapping("/service")
public class UserRestService {
	
	/**
	 * Autowired service to access the user business service
	 */
	@Autowired
	UserBusinessService service;
	
	/**
	 * Method used to get all users
	 * @return Returns all users
	 */
	@GetMapping(path="/Users")
	public ResponseEntity<?> getUsers()
	{
		//Trying to get all the users
		try
		{
			//Calling the user business service to get all the users
			List<UserModel> users = service.getAllUsers();
			//If there are no users throw a not found exception
			if (users == null)
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				//Returning the list of users
				return new ResponseEntity<>(users, HttpStatus.OK);
		}catch (Exception e)
		{
			//If there is an internal server error this throws
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
}
