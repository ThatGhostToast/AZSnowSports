package com.azsnowsports.business;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.azsnowsports.data.UserDataAccessInterface;
import com.azsnowsports.model.UserModel;

/**
 * @author Zac Almas and Austin Driver
 *
 * Business service used for the Users
 */
@SuppressWarnings({"rawtypes", "unchecked"})

public class UserBusinessService implements UserBusinessServiceInterface{
	/**
	 * Current user
	 */
	private UserModel user;
	
	/**
	 * Private attribute used to access our data access layer
	 */
	@Autowired
	private UserDataAccessInterface service;
	
	@Override
	public UserModel getUser() {
		//return the current user
		return this.user;
	}
	
	@Override
	public void setUser(UserModel user) {
		//Set the current user
		this.user = new UserModel(user.getFirstName(), user.getLastName(), user.getEmail(), user.getAddress(), user.getPhoneNumber(), user.getUsername(), user.getPassword());
	}
	
	
	
	@Override
	public UserModel createUser(UserModel newUser) {
		//Sets the current user to the new user
		setUser(newUser);
		//Calls the data access layer to create a user
		service.createUser(newUser);
		//returns the current user
		return getUser();
	}
	
	

	@Override
	public UserModel getUserByUsername(UserModel user) {
		return service.findByUsername(user);
	}

	@Override
	public List<UserModel> getAllUsers(){
		return service.getAllUsers();
	}

	@Override
	public String getUserRole(UserModel user) {
		String role = service.getUsersRole(user);
		
		if (role == null)
		{
			return "User";
		} else {
			return role;
		}
	}
	
}
