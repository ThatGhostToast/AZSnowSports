package com.azsnowsports.business;

import com.azsnowsports.model.UserModel;

/**
 * @author Zac Almas and Austin Driver
 *
 * Interface used for the user business service
 */
public interface UserBusinessServiceInterface {
	/**
	 * Method used to get the current user
	 * @return returns this.user
	 */
	public UserModel getUser();
	/**
	 * Method used to set the current user
	 * @param user User being set
	 */
	public void setUser(UserModel user);
	
	/**
	 * Method used to create a user in the database
	 * @param newUser User that's going to be added into the database
	 * @return returns the current user
	 */
	public UserModel createUser(UserModel newUser);
	
	
	/**
	 * Method used to get a user from the database
	 * @param user User we're looking for
	 * @return returns the user
	 */
	public UserModel getUserByUsername(UserModel user);
	
	/**
	 * Method used to get the users role. (Temporary until we can update the models)
	 * @param user User being checked
	 * @return Returns the users role
	 */
	public String getUserRole(UserModel user);
}
