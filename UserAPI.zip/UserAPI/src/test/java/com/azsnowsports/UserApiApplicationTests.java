package com.azsnowsports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author Zac Almas and Austin Driver
 * 
 * Class for tests
 */
@SpringBootTest
class UserApiApplicationTests {

	/**
	 * Method for tests
	 */
	@Test
	void contextLoads() {
	}

}
